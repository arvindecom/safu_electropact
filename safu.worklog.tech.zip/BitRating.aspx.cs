﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BitRating : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //txtaddress.Text = "";
        //txtbitadd.Text = "";
        //txtcmment.Text = "";
    }

    protected void enter_panel_click(object sender, EventArgs e)
    {
        string url = "https://safu.worklog.tech/binancedata.asmx/fetch_data?btc_address=" + txtaddress.Text + "";
        Response.Redirect(url);
    }

    protected void submit_panel_click(object sender, EventArgs e)
    {
        string url = "https://safu.worklog.tech/binancedata.asmx/Address_data?btc_address='" + txtbitadd.Text + "'&comment=" + txtcmment.Text + "";
        Response.Redirect(url);
    }
}