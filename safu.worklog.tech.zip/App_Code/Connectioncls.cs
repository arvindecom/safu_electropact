﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for Connection
/// </summary
/// >
/// 

public class Connectioncls
{

    //private ClsDataAccess objClsDataccess = new ClsDataAccess(@"Server=SYS04;Database=zondaDaily;integrated security=true");

    // public DataSet Countrow;
    //  public SqlDataAdapter adpt;


    //   public SqlConnection connc = new SqlConnection(ConfigurationManager.AppSettings["conc"]);
    //   public SqlCommand cmd_connc = new SqlCommand();[spUpdate_BIXC_Entry_New_Success_Pending]
    //   public SqlDataReader cmd_reader;

    //private ClsDataAccess objClsDataccess = new ClsDataAccess(@"Server=SYS04;Database=zondaDaily;integrated security=true");

    private dal objClsDataccess = new dal(ConfigurationManager.ConnectionStrings["myConnectionString"].ToString());
 //   private ClsDataAccess objClsDataccess = new ClsDataAccess(ConfigurationManager.AppSettings[0].ToString());

        public SqlDataReader GetdataReader(string strSqlSelectCommand)
        {

            SqlDataReader sdr = objClsDataccess.GetSqlDataReader(strSqlSelectCommand);
            return sdr;
        }

        public int ExecuteSqlnonQuery(string strSqldmlCommand)
        {
            return objClsDataccess.ExecuteDML(strSqldmlCommand);
        }

    //snehal code

    public static DateTime getIndianDateTime()
    {
        DateTime utc, dt;
        dt = DateTime.Now;
        utc = dt.ToUniversalTime();
        dt = utc.AddMinutes(330);
        return dt;
    }

    #region btc_data_add

    public int btc_data_add(string btc_address,string frist_transaction_date,string last_transaction_date,string average,string total_transaction,string total_complain,string total_secure_count,string total_send_count,string total_amount_received,string total_amount_paid,string total_balance,out string rating, out string NewID, out string ErrCode)
    {
        return objClsDataccess.btc_data_add(btc_address, frist_transaction_date, last_transaction_date, average, total_transaction, total_complain, total_secure_count, total_send_count, total_amount_received, total_amount_paid, total_balance, out rating, out NewID, out ErrCode);
    }

    #endregion


    #region add_data_min

    public int add_data_min(string btc_address,string comment, out string NewID, out string ErrCode)
    {
        return objClsDataccess.add_data_min(btc_address, comment, out NewID, out ErrCode);
    }

    #endregion

}