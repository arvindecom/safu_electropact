﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Showdata
{
    public string result { get; set; }

    public Newtonsoft.Json.Linq.JArray message { get; set; }
}
