﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Service_Stop
{

    public string result { get; set; }

    public string message { get; set; }

}
