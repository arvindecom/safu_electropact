﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Text.RegularExpressions;
using System.Net.Mail;
using System.Net.Mime;
using System.Drawing;
using System.Data;
using System.Configuration;
using System.Collections.Specialized;
using System.Net;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Xml;
using System.Text;
using System.Security.Cryptography;
using System.Net;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;

/// <summary>
/// Summary description for yours4organic
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class binancedata : System.Web.Services.WebService {

    Connectioncls ConCls = new Connectioncls();

    string ErrCode;

    public binancedata() {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }


    [WebMethod]
    public void fetch_data(string btc_address)
    {
        try
        { 
        string demon_server_ip = "";
        string demon_server_pass = "";
        string demon_port = "";

        demon_server_ip = ConfigurationManager.AppSettings["demon_server_ip"];
        demon_server_pass = ConfigurationManager.AppSettings["demon_server_pass"];
        demon_port = ConfigurationManager.AppSettings["demon_port"];


        HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(demon_server_ip);
        webRequest.Credentials = new NetworkCredential("userfc", demon_server_pass);
        webRequest.ContentType = "application/json-rpc";
        webRequest.Method = "POST";
        webRequest.Accept = "*/*";
        JObject joe = new JObject();
        joe.Add(new JProperty("jsonrpc", "1.0"));
        joe.Add(new JProperty("id", "curltest"));
        joe.Add(new JProperty("method", "validateaddress"));
        int countelement = joe.Count;
        if (countelement == 0)
        {
            joe.Add(new JProperty("params", new JArray()));
        }
        else
        {
            JArray props = new JArray();
            // add the props in the reverse order!
            for (int i = countelement - 1; i >= 0; i--)
            {
                // add the params
            }
            props.Add(btc_address);

            joe.Add(new JProperty("params", props));
        }
        string s = JsonConvert.SerializeObject(joe);
        byte[] byteArray = Encoding.UTF8.GetBytes(s);
        webRequest.ContentLength = byteArray.Length;
        Stream dataStream = webRequest.GetRequestStream();
        webRequest.KeepAlive = false;
        dataStream.Write(byteArray, 0, byteArray.Length);
        dataStream.Close();
        var httpResponse = (HttpWebResponse)webRequest.GetResponse();

        using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
        {
            string result1 = streamReader.ReadToEnd();

            JObject jobj1 = JObject.Parse(result1);

            string result = jobj1["result"].ToString();

            JObject jobj = JObject.Parse(result);

            string isvalid = jobj["isvalid"].ToString();

            if (isvalid == "True")
            {
                string scriptPubKey = jobj["scriptPubKey"].ToString();

                string url= "https://blockchain.info/rawaddr/" + btc_address;

                const SslProtocols _Tls12 = (SslProtocols)0x00000C00;
                const SecurityProtocolType Tls12 = (SecurityProtocolType)_Tls12;
                ServicePointManager.SecurityProtocol = Tls12;

                HttpWebRequest httpWebRequest1 = WebRequest.Create(url) as HttpWebRequest;

                httpWebRequest1.PreAuthenticate = true;
                httpWebRequest1.Accept = "application/json";
                httpWebRequest1.Accept = "*/*";
                httpWebRequest1.Method = "GET";

                try
                {

                        using (HttpWebResponse responsep = httpWebRequest1.GetResponse() as HttpWebResponse)
                        {
                            // Get the response stream  
                            StreamReader readerp = new StreamReader(responsep.GetResponseStream());
                            string result_p = readerp.ReadToEnd();
                            JObject jobj_prd = JObject.Parse(result_p);


                            string total_transaction = jobj_prd["n_tx"].ToString();
                            string total_complain = "0";
                            string total_secure_count = "0";
                            string total_send_count = jobj_prd["total_sent"].ToString();
                            string total_amount_received = jobj_prd["total_received"].ToString();
                            string total_amount_paid = jobj_prd["total_sent"].ToString();
                            string total_balance = jobj_prd["final_balance"].ToString();

                            float receive = float.Parse(total_amount_received.ToString());

                            float cnt = float.Parse(total_transaction.ToString());

                            string average="";
                            if (cnt == 0)
                            {
                                average = "0";
                            }
                            else
                            {
                                float avg = (receive / cnt) / 100000000;
                                average = avg.ToString();
                            }
                            string txs = jobj_prd["txs"].ToString();
                            JArray jObj1 = JArray.Parse(txs);
                            int count = jObj1.Count;
                            if (count > 0)
                            {
                                for (int j = 0; j < 1; j++)
                                {
                                    for (int i = count - 1; j < 1; j++)
                                    {
                                        double DateTimeReceived = Convert.ToDouble(jObj1[j]["time"].ToString());
                                        double DateTimeReceived1 = Convert.ToDouble(jObj1[i]["time"].ToString());

                                        DateTime frist_transaction_date1 = UnixTimeStampToDateTime(DateTimeReceived);
                                        DateTime last_transaction_date1 = UnixTimeStampToDateTime(DateTimeReceived1);

                                        string frist_transaction_date = frist_transaction_date1.ToString();
                                        string last_transaction_date = last_transaction_date1.ToString();

                                        string NewID = "";
                                        string rating = "";
                                        ConCls.btc_data_add(btc_address, frist_transaction_date, last_transaction_date, average, total_transaction, total_complain, total_secure_count, total_send_count, total_amount_received, total_amount_paid, total_balance,out rating, out NewID, out ErrCode);
                                        if (NewID == "1")
                                        {
                                            address_data_add service = new address_data_add();
                                            service.result = "true";
                                            service.frist_transaction_date = frist_transaction_date;
                                            service.last_transaction_date = last_transaction_date;
                                            service.average = average;
                                            service.total_transaction = total_transaction;
                                           //service.total_complain = total_complain;
                                           // service.total_secure_count = total_secure_count;
                                            service.total_send_count = total_send_count;
                                            service.total_amount_received = total_amount_received;
                                            service.total_amount_paid = total_amount_received;
                                            service.message = ErrCode;
                                            service.rating = rating;
                                            string json = JsonConvert.SerializeObject(service);
                                            this.Context.Response.Write(json);
                                        }
                                        else
                                        {
                                            Service_Stop service = new Service_Stop();
                                            service.result = "false";
                                            service.message = ErrCode;

                                            string json = JsonConvert.SerializeObject(service);
                                            this.Context.Response.Write(json);
                                        }


                                    }
                                }
                            }
                            else
                            {
                                string frist_transaction_date ="";
                                string last_transaction_date = "";

                                string NewID = "";
                                string rating = "";
                                ConCls.btc_data_add(btc_address, frist_transaction_date, last_transaction_date, average, total_transaction, total_complain, total_secure_count, total_send_count, total_amount_received, total_amount_paid, total_balance,out rating, out NewID, out ErrCode);
                                if (NewID == "1")
                                {
                                    address_data_add service = new address_data_add();
                                    service.result = "true";
                                    service.frist_transaction_date = frist_transaction_date;
                                    service.last_transaction_date = last_transaction_date;
                                    service.average = average;
                                    service.total_transaction = total_transaction;
                                    //service.total_complain = total_complain;
                                    //service.total_secure_count = total_secure_count;
                                    service.total_send_count = total_send_count;
                                    service.total_amount_received = total_amount_received;
                                    service.total_amount_paid = total_amount_received;
                                    service.message = ErrCode;
                                    service.rating = rating;
                                    string json = JsonConvert.SerializeObject(service);
                                    this.Context.Response.Write(json);
                                }
                                else
                                {
                                    Service_Stop service = new Service_Stop();
                                    service.result = "false";
                                    service.message = ErrCode;

                                    string json = JsonConvert.SerializeObject(service);
                                    this.Context.Response.Write(json);
                                }
                            }
                        }
                }
                catch (Exception ex)
                {
                    Service_Stop service = new Service_Stop();
                    service.result = "false";
                    service.message = "Address verification fail.";

                    string json = JsonConvert.SerializeObject(service);
                    this.Context.Response.Write(json);
                }
            }
            else
            {
                Service_Stop service = new Service_Stop();
                service.result = "false";
                service.message = "";

                string json = JsonConvert.SerializeObject(service);
                this.Context.Response.Write(json);
            }
        }
    }
    catch (Exception ex)
    {
        Service_Stop service = new Service_Stop();
        service.result = "false";
        service.message = "Address verification fail.";

        string json = JsonConvert.SerializeObject(service);
        this.Context.Response.Write(json);
    }
    }


    public static DateTime UnixTimeStampToDateTime(double unixTimeStamp)
    {
        // Unix timestamp is seconds past epoch
        System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
        dtDateTime = dtDateTime.AddSeconds(unixTimeStamp).ToLocalTime();
        return dtDateTime;
    }

    [WebMethod]
    public void Address_data(string btc_address,string comment)
    {
        string NewID = "";
        ConCls.add_data_min(btc_address, comment, out NewID, out ErrCode);
        if (NewID == "1")
        {
            string constr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("select * from [report_detail] where bitcoin_address='" + btc_address + "'"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            dt.TableName = "[report_detail]";
                            sda.Fill(dt);
                            var json = JsonConvert.SerializeObject(dt);
                            //return dt;

                            dynamic jsonResponse = JsonConvert.DeserializeObject(json);

                            JArray jarray = new JArray(jsonResponse);

                            ShowdataRating service = new ShowdataRating();
                            service.result = "true";
                            service.message = ErrCode;
                            service.comment = jarray;

                            string json1 = JsonConvert.SerializeObject(service);
                            this.Context.Response.Write(json1);
                        }
                    }
                }
            }
        }
        else
        {
            Service_Stop service = new Service_Stop();
            service.result = "false";
            service.message = ErrCode;


            string json = JsonConvert.SerializeObject(service);
            this.Context.Response.Write(json);
        }
    }

    [WebMethod]
    public void show_rating(string btc_address)
    {

        try
        {
            string constr = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("select * from blockchain_rate where bitcoin_address='" + btc_address + "'"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            dt.TableName = "blockchain_rate";
                            sda.Fill(dt);
                            var json = JsonConvert.SerializeObject(dt);
                            //return dt;

                            dynamic jsonResponse = JsonConvert.DeserializeObject(json);

                            JArray jarray = new JArray(jsonResponse);


                            Showdata show = new Showdata();
                            show.result = "true";
                            show.message = jarray;


                            string json1 = JsonConvert.SerializeObject(show);
                            this.Context.Response.Write(json1);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Service_Stop service = new Service_Stop();
            service.result = "false";
            service.message = "Please give first rate";


            string json = JsonConvert.SerializeObject(service);
            this.Context.Response.Write(json);
        }
    }
}
