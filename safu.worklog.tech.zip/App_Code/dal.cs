﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for dal
/// </summary>
/// 


public class dal
{
    #region Public Constructor , takes one argument as sqlconnection string

    /// <summary>
    /// Public Constructor , takes one argument as sqlconnection string
    /// </summary>
    /// <param name="SQLconnectionString">SQLconnectionString</param>
    /// 
    public string ConnectionString1 = "";
    public dal(string SQLconnectionString)
    {
        ConnectionString1 = SQLconnectionString;
    }
    #endregion

    public SqlDataReader GetSqlDataReader(string SqlSelectCommand)
    {
        SqlConnection conc = new SqlConnection(ConnectionString1);
        try
        {
            SqlCommand cmd = new SqlCommand(SqlSelectCommand, conc);
            if (conc.State == ConnectionState.Closed)
                conc.Open();
            SqlDataReader sdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            return sdr;
        }
        catch (SqlException ex)
        {
            conc.Close();
            return null;
        }
    }


    #region Executes Non-Query Statements

    public int ExecuteDML(string SqlDMLcmd)
    {
        SqlConnection conc = new SqlConnection(ConnectionString1);
        try
        {
            int returnval = 0;
            SqlCommand cmd = new SqlCommand(SqlDMLcmd, conc);
            if (conc.State == ConnectionState.Closed)
                conc.Open();
            returnval = cmd.ExecuteNonQuery();
            cmd.Dispose();
            conc.Close();
            return returnval;
        }
        catch (SqlException ex)
        {
            return ex.ErrorCode;
        }
        finally
        {
            conc.Close();
        }
    }
    #endregion

    #region btc_data_add

    public int btc_data_add(string btc_address, string frist_transaction_date, string last_transaction_date, string average, string total_transaction, string total_complain, string total_secure_count, string total_send_count, string total_amount_received, string total_amount_paid, string total_balance,out string rating, out string NewID, out string ErrCode)
    {
        float average1 = 0;
        float total_transaction1 = 0;
        float total_complain1 = 0;
        float total_secure_count1 = 0;
        float total_send_count1 = 0;
        float total_amount_received1 = 0;
        float total_amount_paid1 = 0;
        float total_balance1 = 0;

        average1 = float.Parse(average.ToString());
        total_transaction1 = float.Parse(total_transaction.ToString());
        total_complain1 = float.Parse(total_complain.ToString());
        total_secure_count1 = float.Parse(total_secure_count.ToString());
        total_send_count1 = float.Parse(total_send_count.ToString());
        total_amount_received1 = float.Parse(total_amount_received.ToString());
        total_amount_paid1 = float.Parse(total_amount_paid.ToString());
        total_balance1 = float.Parse(total_balance1.ToString());

        SqlConnection conc = new SqlConnection(ConnectionString1);
        try
        {
            SqlCommand cmd1 = new SqlCommand("btc_data_add", conc);
            cmd1.CommandType = CommandType.StoredProcedure;
            cmd1.Parameters.Add(new SqlParameter("@btc_address", btc_address));
            cmd1.Parameters.Add(new SqlParameter("@frist_transaction_date", frist_transaction_date));
            cmd1.Parameters.Add(new SqlParameter("@last_transaction_date", last_transaction_date));
            cmd1.Parameters.Add(new SqlParameter("@average", average1));
            cmd1.Parameters.Add(new SqlParameter("@total_transaction", total_transaction1));
            cmd1.Parameters.Add(new SqlParameter("@total_complain", total_complain1));
            cmd1.Parameters.Add(new SqlParameter("@total_secure_count", total_secure_count1));
            cmd1.Parameters.Add(new SqlParameter("@total_send_count", total_send_count1));
            cmd1.Parameters.Add(new SqlParameter("@total_amount_received", total_amount_received1));
            cmd1.Parameters.Add(new SqlParameter("@total_amount_paid", total_amount_paid1));
            cmd1.Parameters.Add(new SqlParameter("@total_balance", total_balance1));

            SqlParameter SqlParaNewID = new SqlParameter("@NewID", SqlDbType.VarChar, 500);
            SqlParaNewID.Direction = ParameterDirection.Output;
            cmd1.Parameters.Add(SqlParaNewID).Value = "";

            SqlParameter SqlParaErrMsg = new SqlParameter("@ErrCode", SqlDbType.VarChar, 500);
            SqlParaErrMsg.Direction = ParameterDirection.Output;
            cmd1.Parameters.Add(SqlParaErrMsg).Value = "TRY";

            SqlParameter SqlPararating = new SqlParameter("@rating", SqlDbType.VarChar, 500);
            SqlPararating.Direction = ParameterDirection.Output;
            cmd1.Parameters.Add(SqlPararating).Value = "";

            if (conc.State == ConnectionState.Closed)
                conc.Open();
            int value = cmd1.ExecuteNonQuery();
            NewID = (string)SqlParaNewID.Value;
            ErrCode = (string)SqlParaErrMsg.Value;
            rating = (string)SqlPararating.Value;
            return value;

        }
        catch (Exception ex)
        {
            NewID = "";
            ErrCode = ex.Message;
            rating = "";
            return 0;
        }
        finally
        {
            conc.Close();
        }
    }

    #endregion

    #region add_data_min

    public int add_data_min(string btc_address,string comment, out string NewID, out string ErrCode)
    {
        SqlConnection conc = new SqlConnection(ConnectionString1);
        try
        {
            SqlCommand cmd1 = new SqlCommand("add_data_min", conc);
            cmd1.CommandType = CommandType.StoredProcedure;
            cmd1.Parameters.Add(new SqlParameter("@btc_address", btc_address));
            cmd1.Parameters.Add(new SqlParameter("@comment", comment));

            SqlParameter SqlParaNewID = new SqlParameter("@NewID", SqlDbType.VarChar, 500);
            SqlParaNewID.Direction = ParameterDirection.Output;
            cmd1.Parameters.Add(SqlParaNewID).Value = "";

            SqlParameter SqlParaErrMsg = new SqlParameter("@ErrCode", SqlDbType.VarChar, 500);
            SqlParaErrMsg.Direction = ParameterDirection.Output;
            cmd1.Parameters.Add(SqlParaErrMsg).Value = "TRY";

            if (conc.State == ConnectionState.Closed)
                conc.Open();
            int value = cmd1.ExecuteNonQuery();
            NewID = (string)SqlParaNewID.Value;
            ErrCode = (string)SqlParaErrMsg.Value;
            return value;

        }
        catch (Exception ex)
        {
            NewID = "";
            ErrCode = ex.Message;
            return 0;
        }
        finally
        {
            conc.Close();
        }
    }

    #endregion

}