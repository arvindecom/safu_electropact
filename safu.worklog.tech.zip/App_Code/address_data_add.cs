﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class address_data_add
{
    public string frist_transaction_date { get; set; }

    public string last_transaction_date { get; set; }

    public string average { get; set; }

    public string total_transaction { get; set; }

    //public string total_complain { get; set; }

    //public string total_secure_count { get; set; }

    public string total_send_count { get; set; }

    public string total_amount_received { get; set; }

    public string total_amount_paid { get; set; }

    public string result { get; set; }

    public string message { get; set; }

    public string rating { get; set; }
}
